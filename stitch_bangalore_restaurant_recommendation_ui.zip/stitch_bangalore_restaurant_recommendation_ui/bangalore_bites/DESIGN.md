---
name: Bangalore Bites
colors:
  surface: '#131315'
  surface-dim: '#131315'
  surface-bright: '#39393b'
  surface-container-lowest: '#0e0e10'
  surface-container-low: '#1b1b1d'
  surface-container: '#201f21'
  surface-container-high: '#2a2a2c'
  surface-container-highest: '#353437'
  on-surface: '#e5e1e4'
  on-surface-variant: '#d5c4b1'
  inverse-surface: '#e5e1e4'
  inverse-on-surface: '#313032'
  outline: '#9d8e7d'
  outline-variant: '#514536'
  surface-tint: '#fdba59'
  primary: '#ffc676'
  on-primary: '#452b00'
  primary-container: '#e8a849'
  on-primary-container: '#623f00'
  inverse-primary: '#825500'
  secondary: '#ffb59c'
  on-secondary: '#5c1a00'
  secondary-container: '#7f2b07'
  on-secondary-container: '#ff9b78'
  tertiary: '#a5d5ff'
  on-tertiary: '#003350'
  tertiary-container: '#74bbf3'
  on-tertiary-container: '#004a71'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffddb4'
  primary-fixed-dim: '#fdba59'
  on-primary-fixed: '#291800'
  on-primary-fixed-variant: '#633f00'
  secondary-fixed: '#ffdbcf'
  secondary-fixed-dim: '#ffb59c'
  on-secondary-fixed: '#380c00'
  on-secondary-fixed-variant: '#7f2b07'
  tertiary-fixed: '#cce5ff'
  tertiary-fixed-dim: '#90cdff'
  on-tertiary-fixed: '#001e31'
  on-tertiary-fixed-variant: '#004b72'
  background: '#131315'
  on-background: '#e5e1e4'
  surface-variant: '#353437'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 34px
    fontWeight: '600'
    lineHeight: 42px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  margin: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

Bangalore Bites is an AI-powered restaurant recommendation app tailored for discovering dining experiences across Bangalore. The target audience consists of discerning urban diners, food enthusiasts, and evening explorers seeking curated, trustworthy recommendations—from heritage darshinis and craft breweries in Indiranagar to intimate chef-led tasting rooms in Lavelle Road.

The UI should evoke a calm, premium, and atmospheric evening dining tone—like stepping into a warmly lit, contemporary restaurant after dusk. It balances editorial sophistication with effortless utility, ensuring that AI-driven recommendations feel personal, curated, and appetizing rather than algorithmic.

This design system blends **Minimalism** with **Tonal Layering**:
- **Dark-first, low-glare surfaces** create an intimate, distraction-free canvas that makes food photography and warm typography glow.
- **Editorial typography** pairs expressive serif headlines with clean, approachable sans-serif UI controls.
- **Restrained warm accents** (amber gold and terracotta) guide attention to primary actions, ratings, and curated highlights without overwhelming the senses.

## Colors

The design system operates exclusively in **dark mode**, built on deep charcoal and near-black surfaces that evoke Bangalore's evening dining atmosphere while reducing eye strain.

### Surface & Neutral Hierarchy
- **Canvas Background (`#0D0D0F`)**: The deepest near-black base layer for the main application viewport.
- **Elevated Surface (`#16161A`)**: Used for sticky headers, bottom navigation bars, modals, and drawer sheets.
- **Card Surface (`#1E1E24`)**: The primary container surface for restaurant cards, AI recommendation modules, and interactive panels.
- **Subtle Border (`#2A2A32`)**: Low-contrast hairline borders used to define card edges, dividers, and input outlines.

### Typography Colors
- **Primary Text (`#F5F3EE`)**: Warm off-white for headlines, restaurant names, and primary body copy, ensuring high contrast without the harshness of pure white.
- **Secondary Text (`#A09E97`)**: Muted warm gray for metadata, neighborhood tags, cuisines, and supporting descriptions.

### Accents & Semantic Tokens
- **Primary Accent (`#E8A849`)**: Warm amber/soft gold used for primary CTAs, active states, star ratings, and AI match highlights.
- **Secondary Accent (`#D46A43`)**: Rich terracotta used for secondary badges, spice/flavor indicators, and subtle editorial accents.
- **Success (`#34D399`)**: Used for "Open Now" status indicators, confirmed bookings, and positive match scores.
- **Danger / Error (`#F87171`)**: Used for "Closed" status, validation errors, and destructive actions.

### Hero Atmospheric Wash
Behind the hero search and AI prompt area, apply a subtle radial warm wash (`radial-gradient(circle at 50% 0%, rgba(232, 168, 73, 0.12), rgba(212, 106, 67, 0.05) 45%, transparent 75%)`) over `#0D0D0F` to create a gentle, inviting glow.

## Typography

The typography system pairs **Playfair Display** for editorial warmth and brand distinction with **Plus Jakarta Sans** for crisp, legible UI controls, metadata, and body copy.

- **Playfair Display** is reserved for the brand mark, hero headlines (`display-lg`), section headers (`headline-lg`, `headline-md`), and featured restaurant titles (`headline-sm`). Its high-contrast strokes lend an upscale, culinary-magazine feel.
- **Plus Jakarta Sans** handles all functional interface elements—search inputs, filter chips, neighborhood metadata, ratings, and descriptions—ensuring effortless scannability on dark surfaces.
- On mobile viewports (`< 640px`), `display-lg` scales down to `display-lg-mobile` (`34px`) to preserve generous breathing room around the hero prompt.

## Layout & Spacing

This design system follows a **spacing-first layout** philosophy, using generous negative space to let rich food photography and editorial typography breathe without visual clutter.

### Grid & Breakpoints
- **Fluid 12-Column Grid (Desktop `>= 1024px`)**: Centered container with a `1200px` max-width, `1.25rem` (`20px`) gutters, and `2.5rem` (`40px`) outer margins. Restaurant discovery grids typically use 3 columns (4 spans each).
- **Tablet (`640px – 1023px`)**: 8-column fluid grid with `1.25rem` (`20px`) gutters and `1.5rem` (`24px`) outer margins. Cards reflow to a 2-column grid.
- **Mobile (`< 640px`)**: 4-column fluid grid with `1rem` (`16px`) gutters and `1rem` (`16px`) outer margins. Cards stack in a single column with `1.5rem` (`24px`) vertical rhythm between sections.

### Spacing Rhythm
- Use `space-xs` (`4px`) and `space-sm` (`8px`) for tight internal groupings, such as icon-to-label gaps and rating badge padding.
- Use `space-md` (`16px`) for standard card padding on mobile and gaps between form controls.
- Use `space-lg` (`24px`) for desktop card padding and vertical spacing between content blocks.
- Use `space-xl` (`40px`) for major section separations, such as the transition from the hero AI prompt to the curated restaurant feed.

## Elevation & Depth

In a dark-only environment, traditional drop shadows lose visibility. Instead, this design system communicates hierarchy through **tonal surface layering** and **low-contrast hairline outlines**.

- **Tonal Layering**: Depth increases as surfaces step lighter—from the `#0D0D0F` canvas, to `#16161A` elevated navigation and sheets, up to `#1E1E24` interactive cards.
- **Subtle Outlines**: Cards, input fields, and chips are defined by `1px solid #2A2A32` borders. On hover or focus, borders subtly brighten (e.g., `rgba(232, 168, 73, 0.4)`) to signal interactivity without harsh flashes.
- **Ambient Glows**: Reserved exclusively for the hero radial warm wash and active AI recommendation states, using ultra-soft, low-opacity amber/terracotta gradients rather than hard shadows.

## Shapes

The shape language is **softly rounded**, balancing modern approachability with structured editorial precision.

- **Cards & Containers (`12px` / `0.75rem`)**: Restaurant cards, AI insight panels, and modal sheets use a `12px` border radius for a calm, refined silhouette.
- **Controls & Inputs (`8px` / `0.5rem`)**: Buttons, search inputs, and dropdowns use an `8px` border radius to feel crisp and tactile.
- **Chips & Badges (`9999px` / Pill)**: Neighborhood filters, dietary tags, and status badges use full pill rounding to visually separate metadata from structural containers.

## Components

### Buttons
- **Primary Button**: Solid `#E8A849` background with `#0D0D0F` dark text (`label-lg`, `600` weight), `8px` border radius, and `12px 20px` padding. Hover state shifts to `#F0B760`.
- **Secondary / Ghost Button**: Transparent or `#1E1E24` background with `1px solid #2A2A32` border and `#F5F3EE` text. Hover state subtly tints the background to `#25252C`.

### Chips & Filter Pills
- **Neighborhood & Cuisine Chips**: Pill-shaped (`9999px` radius), `#16161A` background, `1px solid #2A2A32` border, and `#A09E97` text (`label-md`).
- **Active State**: `#E8A849` border at `50%` opacity, subtle `rgba(232, 168, 73, 0.12)` fill, and `#E8A849` text.

### Input Fields (AI Prompt & Search)
- **Container**: `#16161A` background, `1px solid #2A2A32` border, `8px` border radius (`12px` for the hero AI prompt bar), and `12px 16px` padding.
- **Typography**: `#F5F3EE` input text with `#A09E97` placeholder text (`body-lg` in hero, `body-md` in filters).
- **Focus State**: Border transitions to `#E8A849` with a subtle `0 0 0 3px rgba(232, 168, 73, 0.15)` focus ring.

### Restaurant Cards
- **Surface**: `#1E1E24` background, `1px solid #2A2A32` border, `12px` border radius, `overflow: hidden`.
- **Media**: 16:10 aspect ratio food/ambience photography at the top, with an optional floating `#0D0D0F` (80% opacity, `backdrop-filter: blur(8px)`) rating badge in the corner.
- **Content**: `16px`–`24px` padding (`space-md` to `space-lg`). Displays the restaurant name in `headline-sm` (`Playfair Display`), followed by neighborhood, cuisine, and price-for-two metadata in `#A09E97` (`body-md`), and an AI-curated "Why it fits" one-liner.

### Lists & Checkboxes / Radio Buttons
- **Lists**: Separated by `1px solid #2A2A32` hairline dividers with `12px` vertical padding (`space-sm` to `space-md`).
- **Checkboxes & Radios**: `18px` size, `#16161A` fill, `1px solid #2A2A32` border (`4px` radius for checkboxes, `50%` for radios). Checked state fills with `#E8A849` and a `#0D0D0F` checkmark/dot.

### AI Recommendation Callout
- A dedicated `#16161A` container with a `1px solid rgba(232, 168, 73, 0.3)` border, `12px` radius, and a subtle warm left accent or sparkle icon in `#E8A849` to distinguish AI-synthesized dining notes from standard metadata.